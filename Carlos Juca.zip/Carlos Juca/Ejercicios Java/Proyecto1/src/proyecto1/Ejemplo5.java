/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author Salas
 */
public class Ejemplo5 {

    public static void main(String[] args) {
        String nombre = "Carlos";
        String apellido = "Juca";
        int edad = 18;
        double valor = 10.2;
        System.out.printf("%s %s\n\tEdad:%d\n\t$Celular:%.1f\n", nombre, apellido.toUpperCase(), edad, valor);
    }
}
